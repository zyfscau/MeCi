## prepare data for analysis
gzip -dc test.R1.fq.gz > test.R1.fq
gzip -dc test.R2.fq.gz > test.R2.fq

## run MeCi
run_MeCi.pl --in1 test.R1.fq --in2 test.R2.fq --genome NC_007982.1.fa --chunksize 100000
